<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class TblKaryawan extends Migration
{
  /**
  * Run the migrations.
  *
  * @return void
  */
  public function up()
  {
    Schema::create('tbl_karyawan', function (Blueprint $table) {
      $table->increments('id');
      $table->char('nama', 100);
      $table->char('jabatan', 100);
      $table->integer('umur');
      $table->text('alamat');
      $table->char('foto', 100);
    });

  }

  /**
  * Reverse the migrations.
  *
  * @return void
  */
  public function down()
  {
    //
  }
}
